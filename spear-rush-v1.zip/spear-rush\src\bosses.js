// Definição dos bosses. Cada ataque tem fases: windup (telegrafia) -> fire -> active -> recover.
// Assinatura: tele(b,s,g,p) desenha aviso (p = progresso 0..1); fire(b,s) dispara;
// active(b,s,dt,p) roda a cada frame; end(b,s) ao terminar a fase ativa.

const RED = 0xff3355;
const Tele = {
  circle(g, x, y, r, p) {
    g.lineStyle(2, RED, 0.8); g.strokeCircle(x, y, r);
    g.fillStyle(RED, 0.3); g.fillCircle(x, y, r * p);
  },
  cone(g, x, y, r, dir, half, p) {
    g.lineStyle(2, RED, 0.8);
    g.slice(x, y, r, dir - half, dir + half, false); g.strokePath();
    g.fillStyle(RED, 0.3);
    g.slice(x, y, r * p, dir - half, dir + half, false); g.fillPath();
  },
  line(g, x, y, ang, len, w, p) {
    g.lineStyle(w, RED, 0.12 + 0.3 * p);
    g.lineBetween(x, y, x + Math.cos(ang) * len, y + Math.sin(ang) * len);
    g.lineStyle(2, RED, 0.7);
    g.lineBetween(x, y, x + Math.cos(ang) * len, y + Math.sin(ang) * len);
  },
};

function clampBoss(b) {
  b.x = clamp(b.x, ARENA.l + b.r, ARENA.r - b.r);
  b.y = clamp(b.y, ARENA.t + 30, ARENA.b - b.r * 0.6);
}
function chase(b, s, dt, speed, stop) {
  const p = s.p, a = angleTo(b, p);
  if (dist(b, p) > stop) { b.x += Math.cos(a) * speed * dt; b.y += Math.sin(a) * speed * dt; }
  clampBoss(b);
}
function kite(b, s, dt, speed, want) {
  const p = s.p, a = angleTo(b, p), d = dist(b, p);
  b.stT = (b.stT || 0) - dt;
  if (b.stT <= 0) { b.sd = Math.random() < 0.5 ? 1 : -1; b.stT = rnd(1.5, 3); }
  const rad = d < want - 40 ? -1 : d > want + 40 ? 1 : 0;
  let vx = Math.cos(a) * rad + Math.cos(a + Math.PI / 2) * b.sd * 0.6;
  let vy = Math.sin(a) * rad + Math.sin(a + Math.PI / 2) * b.sd * 0.6;
  const l = Math.hypot(vx, vy) || 1;
  b.x += (vx / l) * speed * dt; b.y += (vy / l) * speed * dt;
  clampBoss(b);
}
function fan(b, s, n, spread, speed, o) {
  for (let i = 0; i < n; i++) {
    const a = b.aim + (n === 1 ? 0 : (i / (n - 1) - 0.5) * spread);
    s.spawnProj(b.x, b.y, a, speed, o);
  }
}
function ring(b, s, n, speed, o, off = 0) {
  for (let i = 0; i < n; i++) s.spawnProj(b.x, b.y, off + (i / n) * Math.PI * 2, speed, o);
}
const later = (s, b, ms, fn) => s.time.delayedCall(ms, () => { if (b.alive && !s.p.dead) fn(); });

const BOSSES = [
  // ---------------------------------------------------------------- 1
  {
    name: 'GOLEM DE PEDRA', tex: 'golem', hp: 60, r: 40, speed: 58, cd: [1.0, 1.7],
    move(b, s, dt) { chase(b, s, dt, b.def.speed * (b.phase2 ? 1.35 : 1), 70); },
    attacks: [
      { name: 'slam', wind: 0.95, dur: 0.12, rec: 1.0,
        tele(b, s, g, p) { Tele.circle(g, b.x, b.y + 10, 130, p); },
        fire(b, s) {
          s.meleeHit({ type: 'circle', x: b.x, y: b.y + 10, r: 130 });
          s.shake(180, 0.012); Sfx.boom();
          if (b.phase2) ring(b, s, 10, 250, { tint: 0xc9a76a, r: 10 }, rnd(0, 6));
        } },
      { name: 'charge', wind: 0.85, lock: 0.6, dur: 0.6, rec: 1.1, contact: true,
        tele(b, s, g, p) { Tele.line(g, b.x, b.y, b.aim, 620, b.r * 1.5, p); },
        fire(b) { b.dashAng = b.aim; },
        active(b, s, dt) {
          b.x += Math.cos(b.dashAng) * 600 * dt; b.y += Math.sin(b.dashAng) * 600 * dt; clampBoss(b);
        } },
      { name: 'rocks', wind: 0.65, dur: 0.1, rec: 0.8,
        tele(b, s, g, p) { Tele.line(g, b.x, b.y, b.aim, 500, 6, p); },
        fire(b, s) { fan(b, s, b.phase2 ? 5 : 3, 0.5, 250, { tint: 0xc9a76a, r: 11 }); Sfx.hit(); } },
    ],
  },
  // ---------------------------------------------------------------- 2
  {
    name: 'FEITICEIRA DO VÉU', tex: 'witch', hp: 72, r: 28, speed: 130, cd: [0.9, 1.4],
    move(b, s, dt) { kite(b, s, dt, b.def.speed * (b.phase2 ? 1.25 : 1), 320); },
    attacks: [
      { name: 'fan', wind: 0.6, dur: 0.1, rec: 0.6,
        tele(b, s, g, p) { Tele.line(g, b.x, b.y, b.aim, 500, 6, p); },
        fire(b, s) { fan(b, s, b.phase2 ? 7 : 5, 0.9, 300, { tint: 0xd06bff }); Sfx.hit(); } },
      { name: 'ring', wind: 0.9, dur: 0.1, rec: 0.8,
        tele(b, s, g, p) { Tele.circle(g, b.x, b.y, 60, p); },
        fire(b, s) {
          ring(b, s, 14, 230, { tint: 0xd06bff });
          if (b.phase2) later(s, b, 350, () => ring(b, s, 14, 230, { tint: 0xd06bff }, Math.PI / 14));
          Sfx.hit();
        } },
      { name: 'burst', wind: 0.5, dur: 0.1, rec: 0.9,
        tele(b, s, g, p) { Tele.line(g, b.x, b.y, b.aim, 600, 5, p); },
        fire(b, s) {
          const n = b.phase2 ? 5 : 3;
          for (let i = 0; i < n; i++) later(s, b, i * 180, () => {
            s.spawnProj(b.x, b.y, angleTo(b, s.p), 520, { tint: 0xff9bf0, r: 7 }); Sfx.hit();
          });
        } },
      { name: 'pulse', wind: 0.7, dur: 0.12, rec: 0.7,
        when: (b, s) => dist(b, s.p) < 170,
        tele(b, s, g, p) { Tele.circle(g, b.x, b.y, 150, p); },
        fire(b, s) { s.meleeHit({ type: 'circle', x: b.x, y: b.y, r: 150 }); s.shake(120, 0.008); Sfx.boom(); } },
    ],
  },
  // ---------------------------------------------------------------- 3
  {
    name: 'CAVALEIRO SOMBRIO', tex: 'beast', hp: 90, r: 32, speed: 135, cd: [0.8, 1.3],
    move(b, s, dt) { chase(b, s, dt, b.def.speed * (b.phase2 ? 1.3 : 1), 90); },
    attacks: [
      { name: 'combo', wind: 0.5, repWind: 0.35, lock: 0.7, dur: 0.1, rec: 0.9, repeat: 3,
        tele(b, s, g, p) { Tele.cone(g, b.x, b.y, 120, b.aim, 0.9, p); },
        fire(b, s) {
          s.meleeHit({ type: 'cone', x: b.x, y: b.y, r: 120, dir: b.aim, half: 0.9 });
          b.x += Math.cos(b.aim) * 40; b.y += Math.sin(b.aim) * 40; clampBoss(b); Sfx.hit();
        } },
      { name: 'leap', wind: 0.75, lock: 0.7, dur: 0.45, rec: 1.0,
        tele(b, s, g, p) { Tele.circle(g, b.tx, b.ty, 95, p); },
        fire(b) { b.fx = b.x; b.fy = b.y; },
        active(b, s, dt, p) {
          b.x = Phaser.Math.Linear(b.fx, b.tx, p); b.y = Phaser.Math.Linear(b.fy, b.ty, p);
          b.z = Math.sin(p * Math.PI) * 90; clampBoss(b);
        },
        end(b, s) {
          b.z = 0; s.meleeHit({ type: 'circle', x: b.x, y: b.y, r: 95 }); s.shake(200, 0.014); Sfx.boom();
        } },
      { name: 'daggers', wind: 0.5, dur: 0.1, rec: 0.8,
        tele(b, s, g, p) { Tele.line(g, b.x, b.y, b.aim, 600, 5, p); },
        fire(b, s) { fan(b, s, b.phase2 ? 5 : 4, 0.25, 480, { tint: 0xb0b8ff, r: 7 }); Sfx.hit(); } },
    ],
  },
];
